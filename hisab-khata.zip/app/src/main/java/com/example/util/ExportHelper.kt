package com.example.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.annotation.RequiresApi
import com.example.data.model.TransactionEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportHelper {

    fun exportToCSV(context: Context, transactions: List<TransactionEntity>, lang: String): File? {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val csvHeader = "ID,Type,Amount,Category,Date,Description\n"
        val csvContent = StringBuilder(csvHeader)
        
        for (t in transactions) {
            val formattedDate = sdf.format(Date(t.date))
            val escapedDesc = t.description.replace("\"", "\"\"")
            csvContent.append("${t.id},${t.type},${t.amount},\"${t.category}\",\"$formattedDate\",\"$escapedDesc\"\n")
        }

        return try {
            val fileName = "Hisab_Khata_Export_${System.currentTimeMillis()}.csv"
            val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsDir, fileName)
            FileOutputStream(file).use { out ->
                out.write(csvContent.toString().toByteArray())
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportToPDF(
        context: Context,
        transactions: List<TransactionEntity>,
        totalIncome: Double,
        totalExpense: Double,
        lang: String
    ): File? {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 dimensions in postscript points (72 points/inch)
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint()
        val titlePaint = Paint().apply {
            textSize = 24f
            isFakeBoldText = true
            color = Color.BLACK
        }
        val headerPaint = Paint().apply {
            textSize = 14f
            isFakeBoldText = true
            color = Color.BLACK
        }
        val textPaint = Paint().apply {
            textSize = 10f
            color = Color.DKGRAY
        }
        val boldTextPaint = Paint().apply {
            textSize = 10f
            isFakeBoldText = true
            color = Color.BLACK
        }
        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }

        var y = 50f

        // Title
        val appName = Localization.getString("app_name", lang)
        val invoiceTitle = Localization.getString("export_pdf", lang)
        canvas.drawText(appName, 50f, y, titlePaint)
        y += 30f
        canvas.drawText(invoiceTitle, 50f, y, headerPaint)
        y += 15f
        
        // Date generated
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        canvas.drawText("Generated on: ${sdf.format(Date())}", 50f, y, textPaint)
        y += 30f

        // Summary box
        val incText = Localization.getString("total_income", lang)
        val expText = Localization.getString("total_expense", lang)
        val netText = Localization.getString("profit", lang)
        val lossText = Localization.getString("loss", lang)
        val netProfit = totalIncome - totalExpense

        // Background card for Summary
        paint.color = Color.rgb(245, 245, 245)
        canvas.drawRect(50f, y, 545f, y + 60f, paint)
        
        paint.color = Color.BLACK
        canvas.drawText("$incText: ৳${String.format("%.2f", totalIncome)}", 70f, y + 25f, boldTextPaint)
        canvas.drawText("$expText: ৳${String.format("%.2f", totalExpense)}", 70f, y + 45f, boldTextPaint)

        if (netProfit >= 0) {
            canvas.drawText("$netText: ৳${String.format("%.2f", netProfit)}", 300f, y + 35f, boldTextPaint)
        } else {
            canvas.drawText("$lossText: ৳${String.format("%.2f", -netProfit)}", 300f, y + 35f, boldTextPaint)
        }
        y += 90f

        // Table Headers
        canvas.drawText("Type", 50f, y, headerPaint)
        canvas.drawText("Category", 130f, y, headerPaint)
        canvas.drawText("Date", 230f, y, headerPaint)
        canvas.drawText("Description", 350f, y, headerPaint)
        canvas.drawText("Amount", 480f, y, headerPaint)
        
        y += 10f
        canvas.drawLine(50f, y, 545f, y, linePaint)
        y += 20f

        val itemSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        // Draw up to 15 transactions to fit on the single page nicely
        val displayList = transactions.take(15)
        for (t in displayList) {
            if (y > 800) break // safety break for single page

            val isIncome = t.type == "INCOME"
            val typeStr = Localization.getString(if (isIncome) "income" else "expense", lang)
            
            canvas.drawText(typeStr, 50f, y, if (isIncome) boldTextPaint else textPaint)
            canvas.drawText(t.category, 130f, y, textPaint)
            canvas.drawText(itemSdf.format(Date(t.date)), 230f, y, textPaint)
            
            val truncatedDesc = if (t.description.length > 20) t.description.take(17) + "..." else t.description
            canvas.drawText(truncatedDesc, 350f, y, textPaint)
            
            val amountStr = "${if (isIncome) "+" else "-"}৳${String.format("%.2f", t.amount)}"
            canvas.drawText(amountStr, 480f, y, boldTextPaint)
            
            y += 15f
            canvas.drawLine(50f, y, 545f, y, linePaint)
            y += 20f
        }

        if (transactions.size > 15) {
            canvas.drawText("... and ${transactions.size - 15} more transactions", 50f, y, textPaint)
        }

        pdfDocument.finishPage(page)

        return try {
            val fileName = "Hisab_Khata_Invoice_${System.currentTimeMillis()}.pdf"
            val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsDir, fileName)
            FileOutputStream(file).use { out ->
                pdfDocument.writeTo(out)
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            pdfDocument.close()
        }
    }

    fun backupDatabase(context: Context, transactions: List<TransactionEntity>): File? {
        val jsonArray = JSONArray()
        for (t in transactions) {
            val jsonObject = JSONObject().apply {
                put("type", t.type)
                put("amount", t.amount)
                put("date", t.date)
                put("category", t.category)
                put("description", t.description)
            }
            jsonArray.put(jsonObject)
        }

        return try {
            val fileName = "Hisab_Khata_Backup.json"
            val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloadsDir, fileName)
            FileOutputStream(file).use { out ->
                out.write(jsonArray.toString(4).toByteArray())
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun restoreDatabase(jsonString: String): List<TransactionEntity>? {
        return try {
            val jsonArray = JSONArray(jsonString)
            val list = mutableListOf<TransactionEntity>()
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val type = jsonObject.getString("type")
                val amount = jsonObject.getDouble("amount")
                val date = jsonObject.getLong("date")
                val category = jsonObject.getString("category")
                val description = jsonObject.optString("description", "")
                
                list.add(
                    TransactionEntity(
                        type = type,
                        amount = amount,
                        date = date,
                        category = category,
                        description = description
                    )
                )
            }
            list
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
