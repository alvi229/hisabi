package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.example.data.model.TransactionEntity
import com.example.ui.viewmodel.TransactionViewModel
import com.example.util.Localization
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TransactionViewModel,
    onNavigateToAddTransaction: () -> Unit,
    onNavigateToEditTransaction: (Int) -> Unit,
    onNavigateToIncomeHistory: () -> Unit,
    onNavigateToExpenseHistory: () -> Unit,
    onNavigateToSummaryTab: () -> Unit
) {
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val username by viewModel.accountName.collectAsState()
    val savingPlan by viewModel.savingPlan.collectAsState()

    // Database aggregate values (Current Month)
    val monthIncome by viewModel.currentMonthIncome.collectAsState()
    val monthExpense by viewModel.currentMonthExpense.collectAsState()

    val netProfitLoss = monthIncome - monthExpense

    val latest10 = remember(transactions) {
        transactions.take(10)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = Localization.getString("app_name", lang),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = if (lang == "bn") "হিসাব খাতা • ড্যাশবোর্ড" else "HISAB KHATA • DASHBOARD",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B),
                            letterSpacing = 1.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White),
                actions = {
                    IconButton(
                        onClick = onNavigateToSummaryTab,
                        modifier = Modifier.testTag("summary_icon_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PieChart,
                            contentDescription = "Summary",
                            tint = Color(0xFF2E7D32)
                        )
                    }
                    // Profile/Summary Badge matching Natural Tones header
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(36.dp)
                            .background(Color(0xFFF1F8F1), shape = CircleShape)
                            .border(width = 1.dp, color = Color(0xFF2E7D32).copy(alpha = 0.2f), shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (username.isNotEmpty()) username.take(1).uppercase() else "H",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAddTransaction,
                containerColor = Color(0xFF2E7D32),
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .testTag("add_transaction_fab")
                    .padding(bottom = 60.dp) // Offset for bottom navigation bar safety
                    .border(androidx.compose.foundation.BorderStroke(4.dp, Color.White), RoundedCornerShape(16.dp))
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Transaction")
            }
        },
        containerColor = Color.White
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Natural Tones Month Selector
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .background(Color(0xFFF8FAFC), shape = RoundedCornerShape(16.dp))
                        .border(
                            width = 1.dp,
                            color = Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {}) {
                        Icon(
                            imageVector = Icons.Rounded.ChevronLeft,
                            contentDescription = "Previous Month",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                    val monthEng = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(Date())
                    val monthBen = SimpleDateFormat("MMMM", Locale("bn")).format(Date())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = monthEng,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = monthBen,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    IconButton(onClick = {}) {
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = "Next Month",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }
            }

            // Savings deposit notice if today matches nextDueDate
            if (savingPlan.hasActiveSaving) {
                val cal1 = java.util.Calendar.getInstance()
                val cal2 = java.util.Calendar.getInstance().apply { timeInMillis = savingPlan.nextDueDate }
                val isToday = cal1.get(java.util.Calendar.YEAR) == cal2.get(java.util.Calendar.YEAR) &&
                        cal1.get(java.util.Calendar.DAY_OF_YEAR) == cal2.get(java.util.Calendar.DAY_OF_YEAR)
                
                if (isToday) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5F5)),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD32F2F).copy(alpha = 0.2f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFFD32F2F).copy(alpha = 0.12f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.NotificationsActive,
                                        contentDescription = "Alert",
                                        tint = Color(0xFFD32F2F)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (lang == "bn") "আজ আপনার সঞ্চয়ের জমা দেওয়ার দিন!" else "Today is your savings deposit date!",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD32F2F)
                                    )
                                    Text(
                                        text = if (lang == "bn") {
                                            "সঞ্চয় প্রকল্প: ${savingPlan.name} • কিস্তি: ৳${savingPlan.installmentAmount.toInt()}"
                                        } else {
                                            "Saving Goal: ${savingPlan.name} • Installment: ৳${savingPlan.installmentAmount.toInt()}"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Summary Grid (4 Cards: Income, Expense, Profit, Loss)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Card 1: Total Income
                        SummaryCard(
                            title = Localization.getString("total_income", lang),
                            amount = monthIncome,
                            cardType = "INCOME",
                            icon = Icons.Rounded.TrendingUp,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("income_summary_card")
                                .clickable { onNavigateToIncomeHistory() }
                        )

                        // Card 2: Total Expense
                        SummaryCard(
                            title = Localization.getString("total_expense", lang),
                            amount = monthExpense,
                            cardType = "EXPENSE",
                            icon = Icons.Rounded.TrendingDown,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("expense_summary_card")
                                .clickable { onNavigateToExpenseHistory() }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Card 3: Profit
                        SummaryCard(
                            title = Localization.getString("profit", lang),
                            amount = if (netProfitLoss > 0) netProfitLoss else 0.0,
                            cardType = "PROFIT",
                            icon = Icons.Rounded.TrendingUp,
                            modifier = Modifier.weight(1f)
                        )

                        // Card 4: Loss
                        SummaryCard(
                            title = Localization.getString("loss", lang),
                            amount = if (netProfitLoss < 0) -netProfitLoss else 0.0,
                            cardType = "LOSS",
                            icon = Icons.Rounded.TrendingDown,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Recent Transactions Title / Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Localization.getString("latest_transactions", lang),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    TextButton(
                        onClick = {
                            if (transactions.isNotEmpty()) {
                                if (transactions.first().type == "INCOME") {
                                    onNavigateToIncomeHistory()
                                } else {
                                    onNavigateToExpenseHistory()
                                }
                            } else {
                                onNavigateToIncomeHistory()
                            }
                        }
                    ) {
                        Text(
                            text = "View All",
                            color = Color(0xFF2E7D32),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Transaction List
            if (latest10.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color.LightGray,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = Localization.getString("no_transactions", lang),
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.Gray
                            )
                        }
                    }
                }
            } else {
                items(latest10, key = { it.id }) { item ->
                    TransactionRow(
                        transaction = item,
                        lang = lang,
                        onClick = { onNavigateToEditTransaction(item.id) }
                    )
                }
            }

            // Extra padding at the bottom for navigation bar clearance
            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}

@Composable
fun SummaryCard(
    title: String,
    amount: Double,
    cardType: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    val isIncome = cardType == "INCOME"
    val isExpense = cardType == "EXPENSE"
    val isProfit = cardType == "PROFIT"

    val bgColor = when {
        isIncome -> Color(0xFFF1F8F1)
        isExpense -> Color(0xFFFFF5F5)
        else -> Color.White
    }

    val borderColor = when {
        isIncome -> Color(0xFF2E7D32).copy(alpha = 0.1f)
        isExpense -> Color(0xFFD32F2F).copy(alpha = 0.1f)
        else -> Color(0xFFE2E8F0) // slate-200
    }

    val titleColor = when {
        isIncome -> Color(0xFF2E7D32)
        isExpense -> Color(0xFFD32F2F)
        else -> Color(0xFF64748B) // slate-500
    }

    val valueColor = when {
        isIncome || isExpense -> Color(0xFF1E293B) // slate-800
        isProfit -> Color(0xFF2E7D32)
        else -> if (amount > 0) Color(0xFFD32F2F) else Color(0xFF94A3B8) // slate-400
    }

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = bgColor),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = titleColor,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isIncome -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                                isExpense -> Color(0xFFD32F2F).copy(alpha = 0.15f)
                                else -> Color(0xFFF1F5F9) // slate-100
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = when {
                            isIncome -> Color(0xFF2E7D32)
                            isExpense -> Color(0xFFD32F2F)
                            else -> Color(0xFF64748B)
                        },
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "৳${String.format("%,.2f", amount)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = valueColor
            )
        }
    }
}

@Composable
fun TransactionRow(
    transaction: TransactionEntity,
    lang: String,
    onClick: () -> Unit
) {
    val isIncome = transaction.type == "INCOME"
    val accentColor = if (isIncome) Color(0xFF2E7D32) else Color(0xFFD32F2F)
    val sdfStr = SimpleDateFormat("MMM dd", if (lang == "bn") Locale("bn") else Locale.ENGLISH).format(Date(transaction.date))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("transaction_row_${transaction.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC).copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category Avatar/Box (White box with slate content, matching the HTML design)
            Card(
                modifier = Modifier.size(40.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    val initialChar = if (transaction.category.isNotEmpty()) transaction.category.take(1).uppercase() else "?"
                    Text(
                        text = initialChar,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B) // Slate-500
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Info (Category name & Date/Description)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.category,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A) // slate-900
                )
                Spacer(modifier = Modifier.height(2.dp))
                val subText = if (transaction.description.isNotEmpty()) {
                    "$sdfStr • ${transaction.description}"
                } else {
                    sdfStr
                }
                Text(
                    text = subText,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8), // slate-400
                    maxLines = 1
                )
            }

            // Amount
            Text(
                text = "${if (isIncome) "+" else "-"}৳${String.format("%,.0f", transaction.amount)}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
        }
    }
}

