package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.example.ui.components.CategoryPieChart
import com.example.ui.components.IncomeExpenseBarChart
import com.example.ui.viewmodel.TransactionViewModel
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SummaryScreen(
    viewModel: TransactionViewModel
) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    // Aggregate values (Current Month)
    val monthIncome by viewModel.currentMonthIncome.collectAsState()
    val monthExpense by viewModel.currentMonthExpense.collectAsState()

    val netProfitLoss = monthIncome - monthExpense

    // Category aggregations for the pie chart
    val categoryTotals = remember(transactions) {
        transactions
            .filter { it.type == "EXPENSE" }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = Localization.getString("monthly_summary", lang),
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = if (lang == "bn") "হিসাব খাতা • মাসিক বিবরণী" else "HISAB KHATA • MONTHLY REPORT",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B),
                            letterSpacing = 1.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White),
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.triggerExportPDF(context)
                        },
                        modifier = Modifier.testTag("export_pdf_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "Export PDF",
                            tint = Color(0xFF2E7D32)
                        )
                    }
                }
            )
        },
        containerColor = Color.White
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // General Stats Banner Card
            item {
                val cardBg = if (netProfitLoss >= 0) Color(0xFFF1F8F1) else Color(0xFFFFF5F5)
                val cardBorder = if (netProfitLoss >= 0) Color(0xFF2E7D32).copy(alpha = 0.1f) else Color(0xFFD32F2F).copy(alpha = 0.1f)
                val statusText = if (netProfitLoss >= 0) Localization.getString("profit", lang).uppercase() else Localization.getString("loss", lang).uppercase()
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("summary_net_card"),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, cardBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (netProfitLoss >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "৳${String.format("%,.2f", if (netProfitLoss >= 0) netProfitLoss else -netProfitLoss)}",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )
                    }
                }
            }

            // Section 1: Income vs Expense Comparison Bar Chart
            item {
                Text(
                    text = if (lang == "bn") "আয় বনাম ব্যয় চার্ট" else "INCOME VS EXPENSE",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                IncomeExpenseBarChart(
                    income = monthIncome,
                    expense = monthExpense,
                    incomeLabel = Localization.getString("income", lang),
                    expenseLabel = Localization.getString("expense", lang),
                    modifier = Modifier.testTag("summary_bar_chart")
                )
            }

            // Section 2: Expense Category Breakdown Pie Chart
            item {
                Text(
                    text = if (lang == "bn") "ব্যয় বিভাগ বিভাজন" else "EXPENSE BREAKDOWN BY CATEGORY",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        if (categoryTotals.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No category totals available for this month.",
                                    color = Color.Gray,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        } else {
                            CategoryPieChart(
                                data = categoryTotals,
                                modifier = Modifier.testTag("summary_pie_chart")
                            )
                        }
                    }
                }
            }

            // Bottom Spacer for tab layout clearance
            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }
}
