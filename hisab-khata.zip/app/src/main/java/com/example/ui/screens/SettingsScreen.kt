package com.example.ui.screens

import android.app.AlertDialog
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.example.ui.viewmodel.TransactionViewModel
import com.example.util.Localization

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: TransactionViewModel,
    onNavigateToSavings: () -> Unit = {}
) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val isDark by viewModel.darkMode.collectAsState()
    val currentUsername by viewModel.accountName.collectAsState()

    var showEditNameDialog by remember { mutableStateOf(false) }
    var inputName by remember { mutableStateOf(currentUsername) }

    // Activity launcher for picking backup JSON file (Restore)
    val restoreBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            viewModel.triggerRestore(context, it)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = Localization.getString("settings", lang),
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = if (lang == "bn") "হিসাব খাতা • অ্যাপ সেটিংস" else "HISAB KHATA • APP SETTINGS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B),
                            letterSpacing = 1.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color.White
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // Section 1: User Profile & Account Settings
            item {
                Text(
                    text = Localization.getString("account_settings", lang).uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // User Avatar placeholder
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF1F8F1)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Avatar",
                                tint = Color(0xFF2E7D32),
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentUsername,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = if (lang == "bn") "হিসাব খাতা ইউজার" else "HISAB KHATA MEMBER",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        IconButton(
                            onClick = {
                                inputName = currentUsername
                                showEditNameDialog = true
                            },
                            modifier = Modifier.testTag("edit_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Profile Name",
                                tint = Color(0xFF2E7D32)
                            )
                        }
                    }
                }
            }

            // Section 2: General Application Preferences (Theme, Language)
            item {
                Text(
                    text = (if (lang == "bn") "পছন্দসমূহ" else "PREFERENCES").uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Language Selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newLang = if (lang == "en") "bn" else "en"
                                    viewModel.setLanguage(newLang)
                                }
                                .padding(16.dp)
                                .testTag("preference_language_row"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = Color(0xFF2E7D32)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = Localization.getString("language", lang),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (lang == "en") "English" else "বাংলা",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.Gray
                                    )
                                }
                            }
                            Text(
                                text = if (lang == "en") "বাংলা" else "English",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Divider(color = Color(0xFFEEEEEE), modifier = Modifier.padding(horizontal = 16.dp))

                        // Dark Theme Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .testTag("preference_dark_mode_row"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isDark) Icons.Default.DarkMode else Icons.Default.LightMode,
                                    contentDescription = "Dark Theme",
                                    tint = Color(0xFF2E7D32)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = Localization.getString("dark_theme", lang),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Toggle dark visual layout",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.Gray
                                    )
                                }
                            }
                            Switch(
                                checked = isDark,
                                onCheckedChange = { viewModel.setDarkMode(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF2E7D32),
                                    uncheckedThumbColor = Color.LightGray,
                                    uncheckedTrackColor = Color(0xFFE5E5E5)
                                ),
                                modifier = Modifier.testTag("preference_dark_mode_switch")
                            )
                        }
                    }
                }
            }

            // Section 2.5: Extra Services & Savings
            item {
                Text(
                    text = (if (lang == "bn") "বিশেষ সেবা ও সঞ্চয়" else "EXTRA SERVICES & SAVINGS").uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToSavings() }
                                .padding(16.dp)
                                .testTag("preference_savings_row"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = "Savings Plan",
                                    tint = Color(0xFF2E7D32)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = if (lang == "bn") "হিসাব সঞ্চয় (Savings Plan)" else "Savings Plan",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = if (lang == "bn") "আপনার টাকা সঞ্চয় ও ডিপিএস হিসাব রাখুন" else "Create and manage your offline savings ledger",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Go to savings",
                                tint = Color(0xFF2E7D32)
                            )
                        }
                    }
                }
            }

            // Section 3: Data Import, Export, Backup & Restore
            item {
                Text(
                    text = (if (lang == "bn") "উপাত্ত সংরক্ষণ" else "DATA MANAGEMENT").uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Export to CSV spreadsheet
                        SettingsItem(
                            icon = Icons.Default.GridOn,
                            title = Localization.getString("export_csv", lang),
                            description = "Export transactions list to Excel CSV",
                            onClick = {
                                viewModel.triggerExportCSV(context)
                            },
                            modifier = Modifier.testTag("export_csv_row")
                        )

                        Divider(color = Color(0xFFEEEEEE), modifier = Modifier.padding(horizontal = 16.dp))

                        // Backup JSON
                        SettingsItem(
                            icon = Icons.Default.CloudUpload,
                            title = Localization.getString("backup", lang),
                            description = "Export raw data to local backup JSON file",
                            onClick = {
                                viewModel.triggerBackup(context)
                            },
                            modifier = Modifier.testTag("backup_data_row")
                        )

                        Divider(color = Color(0xFFEEEEEE), modifier = Modifier.padding(horizontal = 16.dp))

                        // Restore JSON
                        SettingsItem(
                            icon = Icons.Default.CloudDownload,
                            title = Localization.getString("restore", lang),
                            description = "Restore backup transaction list from JSON file",
                            onClick = {
                                restoreBackupLauncher.launch("*/*")
                            },
                            modifier = Modifier.testTag("restore_data_row")
                        )

                        Divider(color = Color(0xFFEEEEEE), modifier = Modifier.padding(horizontal = 16.dp))

                        // Reset Database
                        SettingsItem(
                            icon = Icons.Default.DeleteForever,
                            title = Localization.getString("reset_data", lang),
                            description = "Permanently clear and wipe all transactions",
                            titleColor = Color(0xFFD32F2F),
                            onClick = {
                                AlertDialog.Builder(context)
                                    .setTitle("Confirm Reset")
                                    .setMessage("Are you sure you want to permanently delete all transactions? This action cannot be undone.")
                                    .setPositiveButton("Reset") { _, _ ->
                                        viewModel.clearAllTransactions()
                                        Toast.makeText(context, "All data wiped!", Toast.LENGTH_SHORT).show()
                                    }
                                    .setNegativeButton("Cancel", null)
                                    .show()
                            },
                            modifier = Modifier.testTag("reset_data_row")
                        )
                    }
                }
            }

            // Section 4: About & Licensing
            item {
                Text(
                    text = (if (lang == "bn") "অ্যাপ তথ্য" else "APP INFO").uppercase(),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Hisab Khata v1.0.0",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = if (lang == "bn") {
                                "আধুনিক ম্যাটেরিয়াল ৩ ডিজাইন গাইডের আলোকে নির্মিত আয়ের ও ব্যয়ের হিসাব রাখার একটি দ্রুত এবং অফলাইন ট্র্যাকিং অ্যাপ্লিকেশন।"
                            } else {
                                "A high-performance offline-first multi-language income and expense tracker designed and built with modern Material 3 design systems."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // Add bottom spacer
            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Edit profile username Dialog
    if (showEditNameDialog) {
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            title = { Text(text = if (lang == "bn") "অ্যাকাউন্টের নাম পরিবর্তন" else "Edit Account Name", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = inputName,
                    onValueChange = { inputName = it },
                    label = { Text(if (lang == "bn") "নাম লিখুন" else "Account Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("username_input_dialog"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF2E7D32),
                        unfocusedBorderColor = Color(0xFFE2E8F0),
                        focusedLabelColor = Color(0xFF2E7D32)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (inputName.trim().isNotEmpty()) {
                            viewModel.setAccountName(inputName.trim())
                            showEditNameDialog = false
                        }
                    },
                    modifier = Modifier.testTag("save_username_dialog_button")
                ) {
                    Text(text = Localization.getString("save", lang), color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditNameDialog = false }) {
                    Text(text = "Cancel", color = Color(0xFF64748B))
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(24.dp)
        )
    }
}

@Composable
fun SettingsItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    titleColor: Color = Color.Unspecified,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (titleColor == Color(0xFFD32F2F)) Color(0xFFD32F2F) else Color(0xFF2E7D32)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = titleColor
            )
            Text(
                text = description,
                style = MaterialTheme.typography.labelSmall,
                color = Color.Gray
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Details",
            tint = Color.LightGray
        )
    }
}
