package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.example.data.model.TransactionEntity
import com.example.ui.viewmodel.TransactionViewModel
import com.example.util.Localization
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: TransactionViewModel,
    historyType: String = "INCOME", // "INCOME" or "EXPENSE"
    onNavigateBack: () -> Unit,
    onNavigateToEditTransaction: (Int) -> Unit
) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    // Filters state
    var searchQuery by remember { mutableStateOf("") }
    var selectedStartDate by remember { mutableStateOf<Long?>(null) }
    var selectedEndDate by remember { mutableStateOf<Long?>(null) }

    val filteredTransactions = remember(transactions, searchQuery, selectedStartDate, selectedEndDate) {
        transactions.filter { item ->
            val matchType = item.type == historyType
            val matchQuery = searchQuery.isEmpty() || item.category.contains(searchQuery, ignoreCase = true) || item.description.contains(searchQuery, ignoreCase = true)
            val matchStartDate = selectedStartDate == null || item.date >= selectedStartDate!!
            val matchEndDate = selectedEndDate == null || item.date <= selectedEndDate!! + 86399999L // include full day
            matchType && matchQuery && matchStartDate && matchEndDate
        }
    }

    val totalAmount = remember(filteredTransactions) {
        filteredTransactions.sumOf { it.amount }
    }

    val themeColor = if (historyType == "INCOME") Color(0xFF2E7D32) else Color(0xFFD32F2F)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = if (historyType == "INCOME") {
                                Localization.getString("income_history", lang)
                            } else {
                                Localization.getString("expense_history", lang)
                            },
                            fontWeight = FontWeight.Bold,
                            color = themeColor
                        )
                        Text(
                            text = if (lang == "bn") {
                                if (historyType == "INCOME") "আয় ইতিহাস • হিসেব তালিকা" else "ব্যয় ইতিহাস • হিসেব তালিকা"
                            } else {
                                if (historyType == "INCOME") "INCOME HISTORY • LIST" else "EXPENSE HISTORY • LIST"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B),
                            letterSpacing = 1.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = themeColor
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color.White
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Aggregate Top Banner (Total Income / Expense)
            val bannerBg = if (historyType == "INCOME") Color(0xFFF1F8F1) else Color(0xFFFFF5F5)
            val bannerBorder = if (historyType == "INCOME") Color(0xFF2E7D32).copy(alpha = 0.1f) else Color(0xFFD32F2F).copy(alpha = 0.1f)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("history_total_card"),
                colors = CardDefaults.cardColors(containerColor = bannerBg),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, bannerBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (historyType == "INCOME") {
                            Localization.getString("total_income", lang).uppercase()
                        } else {
                            Localization.getString("total_expense", lang).uppercase()
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = themeColor,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "৳${String.format("%,.2f", totalAmount)}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )
                }
            }

            // Filters Section (Search + Date Range Pickers)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(Localization.getString("search_by_date", lang)) }, // search description or category
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = themeColor
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("history_search_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = themeColor,
                        focusedLabelColor = themeColor,
                        unfocusedBorderColor = Color.LightGray
                    ),
                    singleLine = true
                )

                // Date Picker Rows
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Start Date Button
                    FilterDateChip(
                        label = if (selectedStartDate == null) "Start Date" else SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(selectedStartDate!!)),
                        isSelected = selectedStartDate != null,
                        onClick = {
                            val c = Calendar.getInstance()
                            if (selectedStartDate != null) c.timeInMillis = selectedStartDate!!
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val startCal = Calendar.getInstance()
                                    startCal.set(y, m, d, 0, 0, 0)
                                    selectedStartDate = startCal.timeInMillis
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                        onClear = { selectedStartDate = null },
                        themeColor = themeColor,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("filter_start_date_chip")
                    )

                    // End Date Button
                    FilterDateChip(
                        label = if (selectedEndDate == null) "End Date" else SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(selectedEndDate!!)),
                        isSelected = selectedEndDate != null,
                        onClick = {
                            val c = Calendar.getInstance()
                            if (selectedEndDate != null) c.timeInMillis = selectedEndDate!!
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val endCal = Calendar.getInstance()
                                    endCal.set(y, m, d, 23, 59, 59)
                                    selectedEndDate = endCal.timeInMillis
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                        onClear = { selectedEndDate = null },
                        themeColor = themeColor,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("filter_end_date_chip")
                    )
                }
            }

            // List of Filtered Transactions
            if (filteredTransactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = Localization.getString("no_transactions", lang),
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("history_list"),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(filteredTransactions, key = { it.id }) { item ->
                        HistoryRowItem(
                            transaction = item,
                            lang = lang,
                            onClick = { onNavigateToEditTransaction(item.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FilterDateChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    onClear: () -> Unit,
    themeColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(38.dp)
            .clickable(onClick = onClick),
        color = if (isSelected) themeColor else Color(0xFFF5F5F5),
        shape = RoundedCornerShape(19.dp),
        border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = label,
                color = if (isSelected) Color.White else Color.DarkGray,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            if (isSelected) {
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = {
                        onClear()
                    },
                    modifier = Modifier.size(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun HistoryRowItem(
    transaction: TransactionEntity,
    lang: String,
    onClick: () -> Unit
) {
    val isIncome = transaction.type == "INCOME"
    val accentColor = if (isIncome) Color(0xFF2E7D32) else Color(0xFFD32F2F)
    val sdfStr = SimpleDateFormat("MMM dd, yyyy", if (lang == "bn") Locale("bn") else Locale.ENGLISH).format(Date(transaction.date))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("history_row_${transaction.id}"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC).copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category Avatar/Box (White box with slate content)
            Card(
                modifier = Modifier.size(40.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    val initialChar = if (transaction.category.isNotEmpty()) transaction.category.take(1).uppercase() else "?"
                    Text(
                        text = initialChar,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B) // Slate-500
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Info (Category name & Date/Description)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.category,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A) // slate-900
                )
                Spacer(modifier = Modifier.height(2.dp))
                val subText = if (transaction.description.isNotEmpty()) {
                    "$sdfStr • ${transaction.description}"
                } else {
                    sdfStr
                }
                Text(
                    text = subText,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF94A3B8), // slate-400
                    maxLines = 1
                )
            }

            // Amount
            Text(
                text = "${if (isIncome) "+" else "-"}৳${String.format("%,.0f", transaction.amount)}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
        }
    }
}
