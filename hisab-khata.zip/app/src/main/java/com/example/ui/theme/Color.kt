package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Natural Tones Palette
val NaturalGreen = Color(0xFF2E7D32)
val EcoGreen = Color(0xFF4CAF50)
val MintBg = Color(0xFFF1F8F1)
val RoseBg = Color(0xFFFFF5F5)
val DarkSlate = Color(0xFF0F172A)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
val ExpenseRed = Color(0xFFD32F2F)
