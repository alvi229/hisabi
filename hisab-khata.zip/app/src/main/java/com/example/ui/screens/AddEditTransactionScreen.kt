package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.example.data.model.TransactionEntity
import com.example.ui.viewmodel.TransactionViewModel
import com.example.util.Localization
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTransactionScreen(
    viewModel: TransactionViewModel,
    transactionId: Int = -1,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val isEditing = transactionId != -1
    val transaction = remember(transactionId, transactions) {
        if (isEditing) transactions.find { it.id == transactionId } else null
    }

    // Form inputs state
    var type by remember { mutableStateOf(transaction?.type ?: "EXPENSE") }
    var amountStr by remember { mutableStateOf(transaction?.amount?.let { if (it == 0.0) "" else it.toString() } ?: "") }
    var category by remember { mutableStateOf(transaction?.category ?: "") }
    var description by remember { mutableStateOf(transaction?.description ?: "") }
    var dateMillis by remember { mutableStateOf(transaction?.date ?: System.currentTimeMillis()) }

    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    // Predefined lists of categories
    val incomeCategories = remember(lang) { Localization.getIncomeCategories(lang) }
    val expenseCategories = remember(lang) { Localization.getExpenseCategories(lang) }

    val categories = if (type == "INCOME") incomeCategories else expenseCategories

    // Sync categories if type changes and current selection is not valid for type
    LaunchedEffect(type) {
        if (category.isNotEmpty() && !categories.contains(category)) {
            category = categories.firstOrNull() ?: ""
        }
    }

    // Set initial category if empty
    LaunchedEffect(categories, category) {
        if (category.isEmpty()) {
            category = categories.firstOrNull() ?: ""
        }
    }

    val formattedDate = remember(dateMillis) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", if (lang == "bn") Locale("bn") else Locale.ENGLISH)
        sdf.format(Date(dateMillis))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = if (isEditing) {
                                Localization.getString("edit_transaction", lang)
                            } else {
                                Localization.getString("add_transaction", lang)
                            },
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = if (lang == "bn") "হিসাব খাতা • লেনদেন যোগ" else "HISAB KHATA • MANAGE TRANSACTION",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B),
                            letterSpacing = 1.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color(0xFF2E7D32)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White),
                actions = {
                    if (isEditing) {
                        IconButton(
                            onClick = {
                                if (transaction != null) {
                                    viewModel.deleteTransaction(transaction)
                                    onNavigateBack()
                                }
                            },
                            modifier = Modifier.testTag("delete_transaction_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = Color(0xFFD32F2F)
                            )
                        }
                    }
                }
            )
        },
        containerColor = Color.White
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Segmented Controls for Type (Income vs Expense)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(width = 1.dp, color = Color(0xFFF1F5F9), shape = RoundedCornerShape(24.dp)),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Income Button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(4.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (type == "INCOME") Color(0xFF2E7D32) else Color.Transparent)
                        .clickable { type = "INCOME" }
                        .testTag("type_income_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = Localization.getString("income", lang),
                        fontWeight = FontWeight.Bold,
                        color = if (type == "INCOME") Color.White else Color(0xFF2E7D32)
                    )
                }

                // Expense Button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(4.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (type == "EXPENSE") Color(0xFFD32F2F) else Color.Transparent)
                        .clickable { type = "EXPENSE" }
                        .testTag("type_expense_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = Localization.getString("expense", lang),
                        fontWeight = FontWeight.Bold,
                        color = if (type == "EXPENSE") Color.White else Color(0xFFD32F2F)
                    )
                }
            }

            // Amount Input Field (TK)
            OutlinedTextField(
                value = amountStr,
                onValueChange = { input ->
                    if (input.isEmpty() || input.toDoubleOrNull() != null || (input.count { it == '.' } <= 1 && input.all { it.isDigit() || it == '.' })) {
                        amountStr = input
                    }
                },
                label = { Text(Localization.getString("amount", lang)) },
                placeholder = { Text("0.00") },
                leadingIcon = {
                    Text(
                        text = "৳",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (type == "INCOME") Color(0xFF2E7D32) else Color(0xFFD32F2F)
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("amount_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = if (type == "INCOME") Color(0xFF2E7D32) else Color(0xFFD32F2F),
                    unfocusedBorderColor = Color(0xFFE2E8F0),
                    focusedLabelColor = if (type == "INCOME") Color(0xFF2E7D32) else Color(0xFFD32F2F)
                ),
                shape = RoundedCornerShape(16.dp)
            )

            // Date Picker Trigger Field
            OutlinedTextField(
                value = formattedDate,
                onValueChange = {},
                readOnly = true,
                label = { Text(Localization.getString("date", lang)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = "Select Date",
                        tint = Color(0xFF2E7D32)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val calendar = Calendar.getInstance()
                        calendar.timeInMillis = dateMillis
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                val selectedCal = Calendar.getInstance()
                                selectedCal.set(year, month, dayOfMonth)
                                dateMillis = selectedCal.timeInMillis
                            },
                            calendar.get(Calendar.YEAR),
                            calendar.get(Calendar.MONTH),
                            calendar.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }
                    .testTag("date_picker_trigger"),
                enabled = false, // Disables text input, clicks handled by modifier clickable
                colors = OutlinedTextFieldDefaults.colors(
                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                    disabledBorderColor = Color(0xFFE2E8F0),
                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    disabledLeadingIconColor = Color(0xFF2E7D32)
                ),
                shape = RoundedCornerShape(16.dp)
            )

            // Category Picker (Exposed Dropdown Menu style)
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = category,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(Localization.getString("category", lang)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Category,
                            contentDescription = "Category",
                            tint = Color(0xFF2E7D32)
                        )
                    },
                    trailingIcon = {
                        IconButton(onClick = { categoryDropdownExpanded = !categoryDropdownExpanded }) {
                            Icon(
                                imageVector = if (categoryDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                contentDescription = "Dropdown"
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { categoryDropdownExpanded = !categoryDropdownExpanded }
                        .testTag("category_picker_trigger"),
                    enabled = false,
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                        disabledBorderColor = Color(0xFFE2E8F0),
                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        disabledLeadingIconColor = Color(0xFF2E7D32),
                        disabledTrailingIconColor = Color.Gray
                    ),
                    shape = RoundedCornerShape(16.dp)
                )

                DropdownMenu(
                    expanded = categoryDropdownExpanded,
                    onDismissRequest = { categoryDropdownExpanded = false },
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .background(Color.White)
                ) {
                    categories.forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat) },
                            onClick = {
                                category = cat
                                categoryDropdownExpanded = false
                            },
                            modifier = Modifier.testTag("category_option_$cat")
                        )
                    }
                }
            }

            // Description Input Field (Optional)
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text(Localization.getString("description", lang)) },
                placeholder = { Text("Add short details...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Notes,
                        contentDescription = "Description",
                        tint = Color(0xFF2E7D32)
                    )
                },
                maxLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("description_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF2E7D32),
                    unfocusedBorderColor = Color(0xFFE2E8F0),
                    focusedLabelColor = Color(0xFF2E7D32)
                ),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            // Save / Submit Button
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    if (amount <= 0.0) {
                        // Invalidate empty inputs gracefully
                        return@Button
                    }

                    val updatedTransaction = TransactionEntity(
                        id = if (isEditing) transactionId else 0,
                        type = type,
                        amount = amount,
                        category = category,
                        description = description,
                        date = dateMillis
                    )

                    if (isEditing) {
                        viewModel.updateTransaction(updatedTransaction)
                    } else {
                        viewModel.insertTransaction(updatedTransaction)
                    }
                    onNavigateBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_transaction_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2E7D32),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = Localization.getString("save", lang),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
