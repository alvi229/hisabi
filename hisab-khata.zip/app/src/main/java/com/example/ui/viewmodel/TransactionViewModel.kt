package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PreferencesHelper
import com.example.data.database.AppDatabase
import com.example.data.model.TransactionEntity
import com.example.data.repository.TransactionRepository
import com.example.util.ExportHelper
import com.example.util.Localization
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Calendar
import java.util.Date

class TransactionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TransactionRepository
    private val prefs: PreferencesHelper

    init {
        val db = AppDatabase.getDatabase(application)
        repository = TransactionRepository(db.transactionDao())
        prefs = PreferencesHelper(application)
    }

    // App Preferences
    val language: StateFlow<String> = prefs.language
    val darkMode: StateFlow<Boolean> = prefs.darkMode
    val currency: StateFlow<String> = prefs.currency
    val accountName: StateFlow<String> = prefs.accountName
    val accountEmail: StateFlow<String> = prefs.accountEmail
    val savingPlan: StateFlow<com.example.data.model.SavingPlan> = prefs.savingPlan

    // Filter states
    val searchQuery = MutableStateFlow("")
    val selectedDateFilter = MutableStateFlow<Long?>(null) // Filter by specific day (timestamp)

    // DB Source
    private val _dbTransactions = repository.allTransactions

    // Combined filtered transactions
    val transactions: StateFlow<List<TransactionEntity>> = combine(
        _dbTransactions,
        searchQuery,
        selectedDateFilter
    ) { list, query, dateFilter ->
        list.filter { item ->
            // Search filter
            val matchesQuery = query.isEmpty() ||
                    item.category.contains(query, ignoreCase = true) ||
                    item.description.contains(query, ignoreCase = true)

            // Date filter
            val matchesDate = if (dateFilter != null) {
                isSameDay(item.date, dateFilter)
            } else {
                true
            }

            matchesQuery && matchesDate
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Derived states (Calculated from ALL transactions in DB for accuracy)
    val totalIncome: StateFlow<Double> = _dbTransactions.combine(MutableStateFlow(Unit)) { list, _ ->
        list.filter { it.type == "INCOME" }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpense: StateFlow<Double> = _dbTransactions.combine(MutableStateFlow(Unit)) { list, _ ->
        list.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Month summary calculations (Current month)
    val currentMonthIncome: StateFlow<Double> = _dbTransactions.combine(MutableStateFlow(Unit)) { list, _ ->
        list.filter { it.type == "INCOME" && isCurrentMonth(it.date) }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val currentMonthExpense: StateFlow<Double> = _dbTransactions.combine(MutableStateFlow(Unit)) { list, _ ->
        list.filter { it.type == "EXPENSE" && isCurrentMonth(it.date) }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // User operations
    fun setLanguage(lang: String) = prefs.setLanguage(lang)
    fun setDarkMode(isDark: Boolean) = prefs.setDarkMode(isDark)
    fun setCurrency(curr: String) = prefs.setCurrency(curr)
    fun setAccountInfo(name: String, email: String) = prefs.setAccountInfo(name, email)

    fun updateSavingPlan(plan: com.example.data.model.SavingPlan) {
        prefs.updateSavingPlan(plan)
    }

    fun resetSavingPlan() {
        prefs.resetSavingPlan()
    }

    fun depositSaving(amount: Double) {
        val current = savingPlan.value
        if (current.hasActiveSaving) {
            val updated = current.copy(totalSaved = current.totalSaved + amount)
            prefs.updateSavingPlan(updated)
        }
    }

    fun insertTransaction(transaction: TransactionEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insert(transaction)
        }
    }

    fun updateTransaction(transaction: TransactionEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.update(transaction)
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(transaction)
        }
    }

    fun deleteTransactionById(id: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteById(id)
        }
    }

    fun restoreAllTransactions(list: List<TransactionEntity>) {
        viewModelScope.launch(Dispatchers.IO) {
            list.forEach { repository.insert(it) }
        }
    }

    fun clearAllTransactions() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAll()
        }
    }

    fun setAccountName(name: String) {
        setAccountInfo(name, accountEmail.value)
    }

    // Export & Backups
    fun triggerExportCSV(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = _dbTransactions.stateIn(viewModelScope).value
            val file = ExportHelper.exportToCSV(context, list, language.value)
            withContext(Dispatchers.Main) {
                if (file != null) {
                    Toast.makeText(
                        context,
                        "${Localization.getString("export_success", language.value)}\nPath: ${file.name}",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(context, "Export Failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun triggerExportPDF(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = _dbTransactions.stateIn(viewModelScope).value
            val income = totalIncome.value
            val expense = totalExpense.value
            val file = ExportHelper.exportToPDF(context, list, income, expense, language.value)
            withContext(Dispatchers.Main) {
                if (file != null) {
                    Toast.makeText(
                        context,
                        "${Localization.getString("pdf_success", language.value)}\nSaved to Downloads: ${file.name}",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(context, "Export Failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun triggerBackup(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = _dbTransactions.stateIn(viewModelScope).value
            val file = ExportHelper.backupDatabase(context, list)
            withContext(Dispatchers.Main) {
                if (file != null) {
                    Toast.makeText(
                        context,
                        "${Localization.getString("backup_success", language.value)}\nSaved: ${file.name}",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(context, "Backup Failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun triggerRestore(context: Context, fileUri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val inputStream = context.contentResolver.openInputStream(fileUri) ?: return@launch
                val reader = BufferedReader(InputStreamReader(inputStream))
                val stringBuilder = StringBuilder()
                var line: String? = reader.readLine()
                while (line != null) {
                    stringBuilder.append(line)
                    line = reader.readLine()
                }
                reader.close()
                inputStream.close()

                val restoredTransactions = ExportHelper.restoreDatabase(stringBuilder.toString())
                if (restoredTransactions != null) {
                    for (t in restoredTransactions) {
                        repository.insert(t)
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            Localization.getString("restore_success", language.value),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            Localization.getString("restore_fail", language.value),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Restore Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Helper functions
    private fun isSameDay(time1: Long, time2: Long): Boolean {
        val cal1 = Calendar.getInstance().apply { timeInMillis = time1 }
        val cal2 = Calendar.getInstance().apply { timeInMillis = time2 }
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    private fun isCurrentMonth(time: Long): Boolean {
        val itemCal = Calendar.getInstance().apply { timeInMillis = time }
        val nowCal = Calendar.getInstance()
        return itemCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
                itemCal.get(Calendar.MONTH) == nowCal.get(Calendar.MONTH)
    }
}
