package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SavingPlan
import com.example.ui.viewmodel.TransactionViewModel
import com.example.util.Localization
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavingsScreen(
    viewModel: TransactionViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lang by viewModel.language.collectAsState()
    val savingPlan by viewModel.savingPlan.collectAsState()

    var showInvoiceDialog by remember { mutableStateOf(false) }
    var invoicePlanState by remember { mutableStateOf<SavingPlan?>(null) }
    var showDepositDialog by remember { mutableStateOf(false) }

    // Form states (when creating)
    var nameInput by remember { mutableStateOf("") }
    var durationInput by remember { mutableStateOf("") }
    var selectedAmount by remember { mutableStateOf(500.0) }
    var customAmountInput by remember { mutableStateOf("") }
    var isCustomAmountMode by remember { mutableStateOf(false) }
    
    // Frequency selection
    val frequencies = listOf("weekly", "monthly", "6month", "1year", "2year")
    val frequencyLabelsEn = mapOf(
        "weekly" to "Weekly",
        "monthly" to "Monthly",
        "6month" to "6 Months",
        "1year" to "1 Year",
        "2year" to "2 Years"
    )
    val frequencyLabelsBn = mapOf(
        "weekly" to "সাপ্তাহিক",
        "monthly" to "মাসিক",
        "6month" to "৬ মাস",
        "1year" to "১ বছর",
        "2year" to "২ বছর"
    )
    var selectedFrequency by remember { mutableStateOf("monthly") }

    // Next Due Date selection
    val calendar = Calendar.getInstance()
    var nextDueDateState by remember { mutableStateOf(calendar.timeInMillis) }
    val sdf = SimpleDateFormat("dd MMM yyyy", if (lang == "bn") Locale("bn") else Locale.ENGLISH)

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val selectedCal = Calendar.getInstance()
            selectedCal.set(Calendar.YEAR, year)
            selectedCal.set(Calendar.MONTH, month)
            selectedCal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            nextDueDateState = selectedCal.timeInMillis
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    // Helper for today check
    fun isToday(timestamp: Long): Boolean {
        if (timestamp == 0L) return false
        val cal1 = Calendar.getInstance()
        val cal2 = Calendar.getInstance().apply { timeInMillis = timestamp }
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = if (lang == "bn") "হিসাব সঞ্চয় (Savings)" else "Savings Plan",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                        Text(
                            text = if (lang == "bn") "হিসাব খাতা • সঞ্চয় ও ডিপিএস" else "HISAB KHATA • EXTRA SAVINGS SERVICES",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B),
                            letterSpacing = 1.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("savings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color(0xFF2E7D32)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color.White
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Check if there is an active savings plan
            if (savingPlan.hasActiveSaving) {
                // 1. Notice if Next Due Date is Today!
                if (isToday(savingPlan.nextDueDate)) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5F5)),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color(0xFFD32F2F).copy(alpha = 0.2f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFFD32F2F).copy(alpha = 0.12f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.NotificationsActive,
                                        contentDescription = "Alert",
                                        tint = Color(0xFFD32F2F)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (lang == "bn") "আজ আপনার সঞ্চয়ের জমা দেওয়ার দিন!" else "Today is your savings deposit date!",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD32F2F)
                                    )
                                    Text(
                                        text = if (lang == "bn") {
                                            "পরবর্তী জমার তারিখ: ${sdf.format(Date(savingPlan.nextDueDate))}"
                                        } else {
                                            "Next Deposit Date: ${sdf.format(Date(savingPlan.nextDueDate))}"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Active Savings Dashboard Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8F1)),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0xFF2E7D32).copy(alpha = 0.15f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = (if (lang == "bn") "সক্রিয় সঞ্চয় পরিকল্পনা" else "ACTIVE SAVINGS GOAL").uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32),
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = savingPlan.name,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            // Visual circular meter/badge
                            Card(
                                modifier = Modifier.size(140.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = CircleShape,
                                border = BorderStroke(3.dp, Color(0xFF2E7D32)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = if (lang == "bn") "মোট জমা" else "TOTAL SAVED",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF64748B),
                                            fontWeight = FontWeight.Medium
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "৳${String.format("%,.0f", savingPlan.totalSaved)}",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFF2E7D32)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            // Grid of properties
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White, RoundedCornerShape(16.dp))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (lang == "bn") "কিস্তির পরিমাণ" else "Installment",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = "৳${String.format("%,.0f", savingPlan.installmentAmount)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (lang == "bn") "শুরুর তারিখ" else "Started On",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = sdf.format(Date(savingPlan.startDate)),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF0F172A)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (lang == "bn") "সময়কাল / ধরণ" else "Frequency",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = if (lang == "bn") frequencyLabelsBn[savingPlan.frequency] ?: "" else frequencyLabelsEn[savingPlan.frequency] ?: "",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (lang == "bn") "পরবর্তী জমার তারিখ" else "Next Due Date",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF64748B)
                                    )
                                    Text(
                                        text = sdf.format(Date(savingPlan.nextDueDate)),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isToday(savingPlan.nextDueDate)) Color(0xFFD32F2F) else Color(0xFF0F172A)
                                    )
                                }
                            }
                        }
                    }
                }

                // 3. Actions (Deposit installment, Withdraw / Close saving)
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Deposit Button
                        Button(
                            onClick = { showDepositDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("deposit_saving_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(imageVector = Icons.Rounded.AddCard, contentDescription = "Deposit")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == "bn") "সঞ্চয় জমা দিন (Deposit)" else "Deposit Installment",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Withdraw / Close Button (Available anytime)
                        Button(
                            onClick = {
                                invoicePlanState = savingPlan
                                showInvoiceDialog = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("withdraw_saving_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(imageVector = Icons.Rounded.Payments, contentDescription = "Withdraw")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == "bn") "টাকা উত্তোলন করুন (Withdraw)" else "Withdraw Savings",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

            } else {
                // Form to create a new Saving Goal
                item {
                    Text(
                        text = if (lang == "bn") "নতুন সঞ্চয় পরিকল্পনা শুরু করুন" else "Setup a New Savings Goal",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Saving Goal Name
                            OutlinedTextField(
                                value = nameInput,
                                onValueChange = { nameInput = it },
                                label = { Text(if (lang == "bn") "সঞ্চয়ের লক্ষ্য / নাম" else "Savings Goal / Name") },
                                placeholder = { Text(if (lang == "bn") "উদা. ডিপিএস বা জরুরি তহবিল" else "e.g. My DPS or Emergency Fund") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.BookmarkBorder,
                                        contentDescription = "Goal Name",
                                        tint = Color(0xFF2E7D32)
                                    )
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("savings_name_field"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF2E7D32),
                                    unfocusedBorderColor = Color(0xFFE2E8F0),
                                    focusedLabelColor = Color(0xFF2E7D32)
                                ),
                                shape = RoundedCornerShape(16.dp)
                            )

                            // Term / Duration (e.g. 6 Months, 1 Year, etc)
                            OutlinedTextField(
                                value = durationInput,
                                onValueChange = { durationInput = it },
                                label = { Text(if (lang == "bn") "কত দিন এর (মেয়াদ / বিবরণ)" else "Duration / Note") },
                                placeholder = { Text(if (lang == "bn") "উদা. ১ বছর বা ১২০ দিন" else "e.g. 1 year or 120 days") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.HourglassEmpty,
                                        contentDescription = "Duration",
                                        tint = Color(0xFF2E7D32)
                                    )
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("savings_duration_field"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF2E7D32),
                                    unfocusedBorderColor = Color(0xFFE2E8F0),
                                    focusedLabelColor = Color(0xFF2E7D32)
                                ),
                                shape = RoundedCornerShape(16.dp)
                            )

                            // Frequency (Weekly, Monthly, 6 month, 1 year, 2 year)
                            Column {
                                Text(
                                    text = if (lang == "bn") "সঞ্চয়ের কিস্তি ধরন (মেয়াদ)" else "Saving Frequency",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    frequencies.forEach { freq ->
                                        val label = if (lang == "bn") frequencyLabelsBn[freq] ?: "" else frequencyLabelsEn[freq] ?: ""
                                        val isSelected = selectedFrequency == freq
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (isSelected) Color(0xFF2E7D32) else Color(0xFFF1F5F9))
                                                .clickable { selectedFrequency = freq }
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = label,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else Color(0xFF64748B)
                                            )
                                        }
                                    }
                                }
                            }

                            // Preset Installment Amounts (10, 60, 100, 500, 1000)
                            Column {
                                Text(
                                    text = if (lang == "bn") "সঞ্চয় টাকার পরিমাণ (টাকা)" else "Installment Amount (TK)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val amounts = listOf(10.0, 60.0, 100.0, 500.0, 1000.0)
                                    amounts.forEach { amt ->
                                        val isSelected = !isCustomAmountMode && selectedAmount == amt
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (isSelected) Color(0xFF2E7D32) else Color(0xFFF1F5F9))
                                                .border(
                                                    width = 1.dp,
                                                    color = if (isSelected) Color.Transparent else Color(0xFFE2E8F0),
                                                    shape = RoundedCornerShape(12.dp)
                                                )
                                                .clickable {
                                                    isCustomAmountMode = false
                                                    selectedAmount = amt
                                                }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "৳${amt.toInt()}",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else Color(0xFF475569)
                                            )
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                
                                // Custom amount toggle and field
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { isCustomAmountMode = !isCustomAmountMode }
                                ) {
                                    Checkbox(
                                        checked = isCustomAmountMode,
                                        onCheckedChange = { isCustomAmountMode = it },
                                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF2E7D32))
                                    )
                                    Text(
                                        text = if (lang == "bn") "অন্যান্য যেকোনো পরিমাণ লিখুন" else "Enter custom amount instead",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF334155)
                                    )
                                }

                                if (isCustomAmountMode) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    OutlinedTextField(
                                        value = customAmountInput,
                                        onValueChange = { customAmountInput = it },
                                        label = { Text(if (lang == "bn") "কাস্টম পরিমাণ (টাকা)" else "Custom Amount (TK)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Rounded.AccountBalanceWallet,
                                                contentDescription = "Custom Amount",
                                                tint = Color(0xFF2E7D32)
                                            )
                                        },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("savings_custom_amount_field"),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color(0xFF2E7D32),
                                            unfocusedBorderColor = Color(0xFFE2E8F0),
                                            focusedLabelColor = Color(0xFF2E7D32)
                                        ),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                }
                            }

                            // Next Deposit Date Picker Field
                            Column {
                                Text(
                                    text = if (lang == "bn") "প্রথম জমার / সঞ্চয় শুরু তারিখ" else "First Deposit Date",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = sdf.format(Date(nextDueDateState)),
                                    onValueChange = {},
                                    readOnly = true,
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Rounded.CalendarToday,
                                            contentDescription = "Select Date",
                                            tint = Color(0xFF2E7D32)
                                        )
                                    },
                                    trailingIcon = {
                                        IconButton(onClick = { datePickerDialog.show() }) {
                                            Icon(
                                                imageVector = Icons.Rounded.EditCalendar,
                                                contentDescription = "Edit Date",
                                                tint = Color(0xFF64748B)
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { datePickerDialog.show() }
                                        .testTag("savings_date_picker_field"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Color(0xFF2E7D32),
                                        unfocusedBorderColor = Color(0xFFE2E8F0)
                                    ),
                                    shape = RoundedCornerShape(16.dp),
                                    enabled = false
                                )
                            }
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            if (nameInput.trim().isEmpty()) {
                                Toast.makeText(context, if (lang == "bn") "সঞ্চয় প্রকল্পের নাম দিন!" else "Please enter savings goal name!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            
                            val finalAmount = if (isCustomAmountMode) {
                                customAmountInput.toDoubleOrNull() ?: 0.0
                            } else {
                                selectedAmount
                            }

                            if (finalAmount <= 0) {
                                Toast.makeText(context, if (lang == "bn") "সঠিক পরিমাণ লিখুন!" else "Please enter a valid amount!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            // Create and save the new savings plan
                            val plan = SavingPlan(
                                hasActiveSaving = true,
                                name = nameInput.trim(),
                                installmentAmount = finalAmount,
                                frequency = selectedFrequency,
                                duration = durationInput.trim().ifEmpty { if (lang == "bn") "মেয়াদহীন" else "No limit" },
                                nextDueDate = nextDueDateState,
                                totalSaved = 0.0,
                                startDate = Calendar.getInstance().timeInMillis
                            )
                            viewModel.updateSavingPlan(plan)
                            Toast.makeText(context, if (lang == "bn") "নতুন সঞ্চয় শুরু হয়েছে!" else "New savings goal started!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("start_saving_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(imageVector = Icons.Rounded.CheckCircle, contentDescription = "Create")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == "bn") "সঞ্চয় প্রকল্প শুরু করুন" else "Activate Savings Goal",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    // --- DEPOSIT DIALOG ---
    if (showDepositDialog) {
        var depositAmountStr by remember { mutableStateOf(savingPlan.installmentAmount.toInt().toString()) }
        
        AlertDialog(
            onDismissRequest = { showDepositDialog = false },
            title = {
                Text(
                    text = if (lang == "bn") "সঞ্চয় জমা দিন" else "Deposit Savings",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2E7D32)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (lang == "bn") {
                            "আপনার সঞ্চয় প্রকল্পে কিস্তি বা যেকোনো অতিরিক্ত পরিমাণ টাকা জমা দিতে পারেন।"
                        } else {
                            "Add your regular installment or any custom deposit amount into your savings plan."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )
                    OutlinedTextField(
                        value = depositAmountStr,
                        onValueChange = { depositAmountStr = it },
                        label = { Text(if (lang == "bn") "জমা দেওয়ার পরিমাণ" else "Deposit Amount (TK)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF2E7D32),
                            unfocusedBorderColor = Color(0xFFE2E8F0),
                            focusedLabelColor = Color(0xFF2E7D32)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = depositAmountStr.toDoubleOrNull() ?: 0.0
                        if (amt <= 0) {
                            Toast.makeText(context, if (lang == "bn") "সঠিক পরিমাণ লিখুন!" else "Please enter a valid amount!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        
                        viewModel.depositSaving(amt)
                        
                        // Also calculate next due date based on frequency to push it forward
                        val cal = Calendar.getInstance()
                        cal.timeInMillis = savingPlan.nextDueDate
                        when (savingPlan.frequency) {
                            "weekly" -> cal.add(Calendar.WEEK_OF_YEAR, 1)
                            "monthly" -> cal.add(Calendar.MONTH, 1)
                            "6month" -> cal.add(Calendar.MONTH, 6)
                            "1year" -> cal.add(Calendar.YEAR, 1)
                            "2year" -> cal.add(Calendar.YEAR, 2)
                        }
                        viewModel.updateSavingPlan(savingPlan.copy(
                            totalSaved = savingPlan.totalSaved + amt,
                            nextDueDate = cal.timeInMillis
                        ))
                        
                        showDepositDialog = false
                        Toast.makeText(context, if (lang == "bn") "৳$amt সফলভাবে জমা হয়েছে!" else "৳$amt deposited successfully!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) {
                    Text(if (lang == "bn") "জমা দিন" else "Deposit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDepositDialog = false }) {
                    Text(if (lang == "bn") "বাতিল" else "Cancel", color = Color(0xFF64748B))
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(24.dp)
        )
    }

    // --- WITHDRAW INVOICE DIALOG ---
    if (showInvoiceDialog && invoicePlanState != null) {
        val plan = invoicePlanState!!
        
        AlertDialog(
            onDismissRequest = { /* Force action in invoice */ },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Verified,
                        contentDescription = "Success",
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == "bn") "উত্তোলন ইনভয়েস রসিদ" else "Withdrawal Invoice",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (lang == "bn") "হিসাব খাতা সঞ্চয় সেবা" else "HISAB KHATA SAVINGS SERVICE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B),
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                    
                    Divider(color = Color(0xFFE2E8F0))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = if (lang == "bn") "প্রকল্পের নাম:" else "Goal Name:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                        Text(text = plan.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = if (lang == "bn") "মেয়াদ/কত দিন:" else "Duration/Note:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                        Text(text = plan.duration, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = if (lang == "bn") "কিস্তির পরিমাণ:" else "Installment:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                        Text(text = "৳${plan.installmentAmount.toInt()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = if (lang == "bn") "ধরন:" else "Frequency:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                        Text(text = if (lang == "bn") frequencyLabelsBn[plan.frequency] ?: "" else frequencyLabelsEn[plan.frequency] ?: "", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = if (lang == "bn") "শুরুর তারিখ:" else "Start Date:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                        Text(text = sdf.format(Date(plan.startDate)), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = if (lang == "bn") "উত্তোলন তারিখ:" else "Withdrawn On:", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
                        Text(text = sdf.format(Date()), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }

                    Divider(color = Color(0xFFE2E8F0))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = if (lang == "bn") "উত্তোলনকৃত মোট টাকা:" else "TOTAL WITHDRAWN:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        Text(text = "৳${String.format("%,.0f", plan.totalSaved)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32))
                    }
                    
                    Divider(color = Color(0xFFE2E8F0))
                    
                    Text(
                        text = if (lang == "bn") "স্থিতি: সফলভাবে উত্তোলিত ও পরিশোধিত" else "Status: Successfully Withdrawn & Closed",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        // Reset the saving plan so user can configure a new one
                        viewModel.resetSavingPlan()
                        showInvoiceDialog = false
                        invoicePlanState = null
                        Toast.makeText(context, if (lang == "bn") "সঞ্চয় প্রকল্প সম্পন্ন হয়েছে। নতুন সঞ্চয় করতে পারবেন!" else "Savings closed. You can now start a new saving plan!", Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (lang == "bn") "রসিদ বন্ধ করুন এবং নতুন সঞ্চয় শুরু করুন" else "Close Invoice & Start New Saving")
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(24.dp)
        )
    }
}
