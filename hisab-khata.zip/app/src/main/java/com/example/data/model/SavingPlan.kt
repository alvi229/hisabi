package com.example.data.model

data class SavingPlan(
    val hasActiveSaving: Boolean = false,
    val name: String = "",
    val installmentAmount: Double = 0.0,
    val frequency: String = "monthly", // "weekly", "monthly", "6month", "1year", "2year"
    val duration: String = "",
    val nextDueDate: Long = 0L,
    val totalSaved: Double = 0.0,
    val startDate: Long = 0L
)
