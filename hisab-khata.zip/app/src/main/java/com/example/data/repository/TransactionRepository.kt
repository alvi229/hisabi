package com.example.data.repository

import com.example.data.dao.TransactionDao
import com.example.data.model.TransactionEntity
import kotlinx.coroutines.flow.Flow

class TransactionRepository(private val transactionDao: TransactionDao) {
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()

    fun getTransactionsByType(type: String): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByType(type)

    fun getTransactionById(id: Int): Flow<TransactionEntity?> =
        transactionDao.getTransactionById(id)

    suspend fun insert(transaction: TransactionEntity) =
        transactionDao.insertTransaction(transaction)

    suspend fun update(transaction: TransactionEntity) =
        transactionDao.updateTransaction(transaction)

    suspend fun delete(transaction: TransactionEntity) =
        transactionDao.deleteTransaction(transaction)

    suspend fun deleteById(id: Int) =
        transactionDao.deleteTransactionById(id)

    suspend fun deleteAll() =
        transactionDao.deleteAllTransactions()
}
