package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class PreferencesHelper(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("hisab_khata_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LANGUAGE = "key_language"
        private const val KEY_DARK_MODE = "key_dark_mode"
        private const val KEY_CURRENCY = "key_currency"
        private const val KEY_ACCOUNT_NAME = "key_account_name"
        private const val KEY_ACCOUNT_EMAIL = "key_account_email"
        private const val KEY_SAVING_ACTIVE = "key_saving_active"
        private const val KEY_SAVING_NAME = "key_saving_name"
        private const val KEY_SAVING_INSTALLMENT = "key_saving_installment"
        private const val KEY_SAVING_FREQUENCY = "key_saving_frequency"
        private const val KEY_SAVING_DURATION = "key_saving_duration"
        private const val KEY_SAVING_NEXT_DUE = "key_saving_next_due"
        private const val KEY_SAVING_TOTAL = "key_saving_total"
        private const val KEY_SAVING_START = "key_saving_start"
    }

    private val _language = MutableStateFlow(prefs.getString(KEY_LANGUAGE, "en") ?: "en")
    val language: StateFlow<String> = _language

    private val _darkMode = MutableStateFlow(prefs.getBoolean(KEY_DARK_MODE, false))
    val darkMode: StateFlow<Boolean> = _darkMode

    private val _currency = MutableStateFlow(prefs.getString(KEY_CURRENCY, "BDT (৳)") ?: "BDT (৳)")
    val currency: StateFlow<String> = _currency

    private val _accountName = MutableStateFlow(prefs.getString(KEY_ACCOUNT_NAME, "User Profile") ?: "User Profile")
    val accountName: StateFlow<String> = _accountName

    private val _accountEmail = MutableStateFlow(prefs.getString(KEY_ACCOUNT_EMAIL, "user@example.com") ?: "user@example.com")
    val accountEmail: StateFlow<String> = _accountEmail

    private val _savingPlan = MutableStateFlow(readSavingPlan())
    val savingPlan: StateFlow<com.example.data.model.SavingPlan> = _savingPlan

    private fun readSavingPlan(): com.example.data.model.SavingPlan {
        return com.example.data.model.SavingPlan(
            hasActiveSaving = prefs.getBoolean(KEY_SAVING_ACTIVE, false),
            name = prefs.getString(KEY_SAVING_NAME, "") ?: "",
            installmentAmount = prefs.getFloat(KEY_SAVING_INSTALLMENT, 0.0f).toDouble(),
            frequency = prefs.getString(KEY_SAVING_FREQUENCY, "monthly") ?: "monthly",
            duration = prefs.getString(KEY_SAVING_DURATION, "") ?: "",
            nextDueDate = prefs.getLong(KEY_SAVING_NEXT_DUE, 0L),
            totalSaved = prefs.getFloat(KEY_SAVING_TOTAL, 0.0f).toDouble(),
            startDate = prefs.getLong(KEY_SAVING_START, 0L)
        )
    }

    fun updateSavingPlan(plan: com.example.data.model.SavingPlan) {
        prefs.edit()
            .putBoolean(KEY_SAVING_ACTIVE, plan.hasActiveSaving)
            .putString(KEY_SAVING_NAME, plan.name)
            .putFloat(KEY_SAVING_INSTALLMENT, plan.installmentAmount.toFloat())
            .putString(KEY_SAVING_FREQUENCY, plan.frequency)
            .putString(KEY_SAVING_DURATION, plan.duration)
            .putLong(KEY_SAVING_NEXT_DUE, plan.nextDueDate)
            .putFloat(KEY_SAVING_TOTAL, plan.totalSaved.toFloat())
            .putLong(KEY_SAVING_START, plan.startDate)
            .apply()
        _savingPlan.value = plan
    }

    fun resetSavingPlan() {
        prefs.edit()
            .putBoolean(KEY_SAVING_ACTIVE, false)
            .putString(KEY_SAVING_NAME, "")
            .putFloat(KEY_SAVING_INSTALLMENT, 0.0f)
            .putString(KEY_SAVING_FREQUENCY, "monthly")
            .putString(KEY_SAVING_DURATION, "")
            .putLong(KEY_SAVING_NEXT_DUE, 0L)
            .putFloat(KEY_SAVING_TOTAL, 0.0f)
            .putLong(KEY_SAVING_START, 0L)
            .apply()
        _savingPlan.value = com.example.data.model.SavingPlan()
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString(KEY_LANGUAGE, lang).apply()
        _language.value = lang
    }

    fun setDarkMode(isDark: Boolean) {
        prefs.edit().putBoolean(KEY_DARK_MODE, isDark).apply()
        _darkMode.value = isDark
    }

    fun setCurrency(curr: String) {
        prefs.edit().putString(KEY_CURRENCY, curr).apply()
        _currency.value = curr
    }

    fun setAccountInfo(name: String, email: String) {
        prefs.edit()
            .putString(KEY_ACCOUNT_NAME, name)
            .putString(KEY_ACCOUNT_EMAIL, email)
            .apply()
        _accountName.value = name
        _accountEmail.value = email
    }
}
