package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.TransactionViewModel
import com.example.util.Localization

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: TransactionViewModel = viewModel()
            val isDarkPref by viewModel.darkMode.collectAsState()
            val lang by viewModel.language.collectAsState()

            MyApplicationTheme(darkTheme = isDarkPref, dynamicColor = false) {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                // Determine whether to show the Bottom Navigation Bar (only on main tab routes)
                val showBottomBar = currentRoute in listOf("tab_home", "tab_summary", "tab_settings")

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar(
                                containerColor = Color.White,
                                modifier = Modifier
                                    .windowInsetsPadding(WindowInsets.navigationBars)
                                    .testTag("main_navigation_bar")
                            ) {
                                NavigationBarItem(
                                    selected = currentRoute == "tab_home",
                                    onClick = {
                                        navController.navigate("tab_home") {
                                            popUpTo("tab_home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentRoute == "tab_home") Icons.Filled.Home else Icons.Outlined.Home,
                                            contentDescription = "Home"
                                        )
                                    },
                                    label = { Text(text = Localization.getString("home", lang)) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFF2E7D32),
                                        selectedTextColor = Color(0xFF2E7D32),
                                        indicatorColor = Color(0xFFE8F5E9)
                                    ),
                                    modifier = Modifier.testTag("nav_home_tab")
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "tab_summary",
                                    onClick = {
                                        navController.navigate("tab_summary") {
                                            popUpTo("tab_home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentRoute == "tab_summary") Icons.Filled.PieChart else Icons.Outlined.PieChart,
                                            contentDescription = "Summary"
                                        )
                                    },
                                    label = { Text(text = Localization.getString("summary", lang)) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFF2E7D32),
                                        selectedTextColor = Color(0xFF2E7D32),
                                        indicatorColor = Color(0xFFE8F5E9)
                                    ),
                                    modifier = Modifier.testTag("nav_summary_tab")
                                )

                                NavigationBarItem(
                                    selected = currentRoute == "tab_settings",
                                    onClick = {
                                        navController.navigate("tab_settings") {
                                            popUpTo("tab_home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (currentRoute == "tab_settings") Icons.Filled.Settings else Icons.Outlined.Settings,
                                            contentDescription = "Settings"
                                        )
                                    },
                                    label = { Text(text = Localization.getString("settings", lang)) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFF2E7D32),
                                        selectedTextColor = Color(0xFF2E7D32),
                                        indicatorColor = Color(0xFFE8F5E9)
                                    ),
                                    modifier = Modifier.testTag("nav_settings_tab")
                                )
                            }
                        }
                    },
                    containerColor = Color.White
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "tab_home",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("tab_home") {
                            HomeScreen(
                                viewModel = viewModel,
                                onNavigateToAddTransaction = { navController.navigate("add_edit_transaction/-1") },
                                onNavigateToEditTransaction = { id -> navController.navigate("add_edit_transaction/$id") },
                                onNavigateToIncomeHistory = { navController.navigate("income_history") },
                                onNavigateToExpenseHistory = { navController.navigate("expense_history") },
                                onNavigateToSummaryTab = { navController.navigate("tab_summary") }
                            )
                        }

                        composable("tab_summary") {
                            SummaryScreen(viewModel = viewModel)
                        }

                        composable("tab_settings") {
                            SettingsScreen(
                                viewModel = viewModel,
                                onNavigateToSavings = { navController.navigate("savings") }
                            )
                        }

                        composable("savings") {
                            SavingsScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = "add_edit_transaction/{id}",
                            arguments = listOf(navArgument("id") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val id = backStackEntry.arguments?.getInt("id") ?: -1
                            AddEditTransactionScreen(
                                viewModel = viewModel,
                                transactionId = id,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }

                        composable("income_history") {
                            HistoryScreen(
                                viewModel = viewModel,
                                historyType = "INCOME",
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToEditTransaction = { id -> navController.navigate("add_edit_transaction/$id") }
                            )
                        }

                        composable("expense_history") {
                            HistoryScreen(
                                viewModel = viewModel,
                                historyType = "EXPENSE",
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToEditTransaction = { id -> navController.navigate("add_edit_transaction/$id") }
                            )
                        }
                    }
                }
            }
        }
    }
}
